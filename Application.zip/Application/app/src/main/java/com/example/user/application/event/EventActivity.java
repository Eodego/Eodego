package com.example.user.application.event;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by 보운 on 2015-08-30.
 */
public class EventActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        setContentView(R.layout.event_main);
    }
}
