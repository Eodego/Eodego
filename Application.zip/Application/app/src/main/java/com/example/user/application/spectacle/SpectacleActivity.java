package com.example.user.application.spectacle;

import android.app.Activity;
import android.os.Bundle;

import com.example.user.application.R;

/**
 * Created by 보운 on 2015-08-30.
 */
public class SpectacleActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.spectacle_main);
    }
}
