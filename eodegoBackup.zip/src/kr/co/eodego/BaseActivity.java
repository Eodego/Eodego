package kr.co.eodego;

import android.app.Activity;
import android.support.v4.app.FragmentActivity;

public class BaseActivity extends FragmentActivity{
	
	

}
